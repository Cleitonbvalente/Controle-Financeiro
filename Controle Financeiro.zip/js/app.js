import {Receita} from "./receita.js"
import {Despesa} from "./despesa.js"
import {salvarDados, carregarDados} from "./storage.js"
import {categorias} from "./categorias.js"

// IIFE
// Usada para inicialização do sistema

(function(){
console.log("Sistema de Controle Financeiro iniciado")
})()

// carregando dados
let {receitas, despesas} = carregarDados()

// DOM
// seleciona os elementos
const listaReceitas = document.querySelector("#listaReceitas")
const listaDespesas = document.querySelector("#listaDespesas")
const saldoEl = document.querySelector("#saldo")
const mesFiltro = document.querySelector("#mesFiltro")

// eventos
document.querySelector("#btnReceita")
.addEventListener("click", adicionarReceita)

document.querySelector("#btnDespesa")
.addEventListener("click", adicionarDespesa)

mesFiltro.addEventListener("change", render)

// adicionar receita
function adicionarReceita(){

const titulo = document.querySelector("#tituloReceita").value
const valor = document.querySelector("#valorReceita").value
const data = document.querySelector("#dataReceita").value

if(!titulo || !valor){
alert("Preencha todos os campos")
return
}

const receita = new Receita(titulo, valor, data)
receitas = [...receitas, receita]
salvarDados(receitas, despesas)

// limpar campos
document.querySelector("#tituloReceita").value = ""
document.querySelector("#valorReceita").value = ""
document.querySelector("#dataReceita").value = ""

render()

}

// adicionar despesa
function adicionarDespesa(){

const titulo = document.querySelector("#tituloDespesa").value
const valor = document.querySelector("#valorDespesa").value
const categoria = document.querySelector("#categoriaDespesa").value
const data = document.querySelector("#dataDespesa").value

if(!titulo || !valor){
alert("Preencha todos os campos")
return
}

const despesa = new Despesa(titulo, valor, categoria, data)
despesas.push(despesa)
salvarDados(receitas, despesas)

// limpar campos

document.querySelector("#tituloDespesa").value = ""
document.querySelector("#valorDespesa").value = ""
document.querySelector("#categoriaDespesa").value = ""
document.querySelector("#dataDespesa").value = ""

render()

}

// render
// Atualiza a interface
function render(){

listaReceitas.innerHTML = ""
listaDespesas.innerHTML = ""

let receitasFiltradas = receitas
let despesasFiltradas = despesas

const mes = mesFiltro.value

if(mes){
receitasFiltradas = receitas.filter(r => r.data.startsWith(mes))
despesasFiltradas = despesas.filter(d => d.data.startsWith(mes))
}

// sort
// Ordena as receitas pela data
receitasFiltradas.sort((a,b)=> new Date(b.data) - new Date(a.data))

// for of
// Percorre todas as receitas filtradas
for(const r of receitasFiltradas){
const li = document.createElement("li")
li.innerHTML = `${r.titulo} - R$ ${r.valor} - ${r.data}`
listaReceitas.appendChild(li)
}

// foreach
// Percorre todas as despesas filtradas
despesasFiltradas.forEach(d => {
const icone = categorias.get(d.categoria) || ""
const li = document.createElement("li")
li.innerHTML = `${icone} ${d.titulo} - R$ ${d.valor} - ${d.data}`
listaDespesas.appendChild(li)
})

calcularSaldo()

}

// reduce
function calcularSaldo(){
const totalReceitas = receitas.reduce((acc, r) => acc + Number(r.valor), 0)
const totalDespesas = despesas.reduce((acc, d) => acc + Number(d.valor), 0)
saldoEl.innerText = `Saldo: R$ ${totalReceitas - totalDespesas}`
}

/* find */

function buscarDespesa(id){

return despesas.find(d => d.id === id)

}

/* closure */

function criarContador(){
let total = 0
return valor => {
total += valor
return total
}

}

render()
